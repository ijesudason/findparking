import { Component,ViewChild ,ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams,Content} from 'ionic-angular';
import { Geolocation ,GeolocationOptions ,Geoposition ,PositionError } from '@ionic-native/geolocation'; 
import { Http } from '@angular/http';
import { NativeGeocoder} from '@ionic-native/native-geocoder';
import { ToastController } from 'ionic-angular';

declare var google;


/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  
  posts:any;
  options : GeolocationOptions;
  currentmarker:any;
  currentmarkers : any = [];
  currentlat: any;
  currentlng: any;
  createdmarkers: any=[];
  @ViewChild('map') mapElement: ElementRef;
  map: any;

  constructor( public navCtrl: NavController, public navParams: NavParams,private geolocation : Geolocation,public geocoder: NativeGeocoder,public toaster: ToastController,public http: Http) {
  }
  
  ionViewDidLoad(){
	console.log( "page" );
	this.getUserPosition();
  } 
   
  getUserPosition(){
    this.options = {
        enableHighAccuracy : true
    };
  
	this.geolocation.getCurrentPosition(this.options).then((pos : Geoposition) => {

		this.currentlat = pos.coords.latitude;  
		this.currentlng = pos.coords.longitude;    
		//console.log(pos.coords.latitude);
		this.addMap(this.currentlat,this.currentlng);

	},(err : PositionError)=>{
		console.log("error : " + err.message);
	});
  }
  
  addMap(lat,long){
 
	let latLng = new google.maps.LatLng(lat, long);
 
    let mapOptions = {
      center: latLng,
      zoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
    this.addMarker1(latLng);
    this.map.addListener( 'click', (event) =>  {
      //infoWindow.open(this.map, marker);
      console.log('map clicked'+event.latLng.lat());
      console.log('map clicked'+event.latLng.lng());

     this.currentmarker.setPosition(event.latLng);
      
  
    
     
      });
 
}
   

addMarker1(latLng){

  let marker1 = new google.maps.Marker({
	  map: this.map,
	  animation: google.maps.Animation.DROP,
	  draggable: false,
  });
  marker1.setPosition(latLng);
  this.currentmarker=marker1;
  this.createdmarkers.push(marker1);
  let content = "<p>This is your current position !</p>";   

  let infoWindow = new google.maps.InfoWindow({
	content: content
  });

  google.maps.event.addListener(marker1, 'click', () =>  {
    //infoWindow.open(this.map, marker);
	console.log('search');
	//console.log(this.currentmarker.getPosition().lat());
	//console.log( this.currentmarker.getPosition().lng());
	this.search();
  });
  
  google.maps.event.addListener(marker1, 'dragend', function(event) {
    //infoWindow.open(this.map, marker);
     this.currentlat=null;
     this.currentlng=null;
     this.currentlat=marker1.getPosition().lat();
     this.currentlng=marker1.getPosition().lng();
     //console.log(this.currentlat);
	 //console.log( this.currentlng);
	 let latLng = new google.maps.LatLng(this.currentlat,this.currentlng);
	 //this.map.setCenter(latLng);
	 marker1.setPosition(latLng);
	 this.currentmarker= marker1;
    });
    
  
    
}

	search (){
	  this.currentmarkers.forEach(element => {
		element.setMap(null);
    });
    this.currentmarkers=[];
	  //console.log(this.currentmarker.getPosition().lat());
	  //console.log( this.currentmarker.getPosition().lng());
	  this.http.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+this.currentmarker.getPosition().lat()+','+this.currentmarker.getPosition().lng()+'&radius=20&types=hotel&sensor=false&key=AIzaSyDl_34S5JNPTiD_3-CVieJM0HJUmw8W720').map(res => res.json()).subscribe(data => {
		  this.posts = data.results;
		   console.log(this.posts);
		  this.posts.forEach(element => {
		   if(element.name==='Bengaluru'){
        return ;
       }
			  var image = 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png';

			  let marker = new google.maps.Marker({
				map: this.map,
				animation: google.maps.Animation.DROP,
				position: element.geometry.location,
				icon: image
			  });
			  this.currentmarkers.push(marker) ;        
			  let infoWindow = new google.maps.InfoWindow({
        content: element.name+'<br>Parking Slots: '+ Math.floor(Math.random()*20)+1
       

			  }); 
			  google.maps.event.addListener(marker, 'click', () => {
        infoWindow.open(this.map, marker);
        
			  });
		 });
	   });
	}

}



