import { Component,ViewChild ,ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams,Content} from 'ionic-angular';

import { Geolocation ,GeolocationOptions ,Geoposition ,PositionError } from '@ionic-native/geolocation'; 
import { Http } from '@angular/http';
import { NativeGeocoder} from '@ionic-native/native-geocoder';
import {  ToastController } from 'ionic-angular';
//import {GoogleMapsEvent}  from 'ionic-native';
declare var google;


/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  addMarker(): any {
    throw new Error("Method not implemented.");
  }
  
  posts:any;
  options : GeolocationOptions;
  currentmarker:any;
  currentmarkers : any = [];
  currentlat: any;
  currentlng: any;
  @ViewChild('map') mapElement: ElementRef;
  map: any;

  constructor( public navCtrl: NavController, public navParams: NavParams,private geolocation : Geolocation,public geocoder: NativeGeocoder,public toaster: ToastController,public http: Http) {
  }
   
 getUserPosition(){
    this.options = {
        enableHighAccuracy : true
    };
  
  this.geolocation.getCurrentPosition(this.options).then((pos : Geoposition) => {

    this.currentlat = pos.coords.latitude;  
    this.currentlng = pos.coords.longitude;    
    console.log(pos.coords.latitude);
    this.addMap(this.currentlat,this.currentlng);

},(err : PositionError)=>{
    console.log("error : " + err.message);
});
  }
addMap(lat,long){
 
  let latLng = new google.maps.LatLng(lat, long);
 
    //let latLng = new google.maps.LatLng(-34, 151);
   
    let mapOptions = {
    
      center: latLng,
      
      
      zoom: 15,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    
    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
    //let bound = new google.maps.LatLngBounds();
    this.addMarker1(latLng);
 
}
ionViewDidLoad(){
 console.log( "page" );
  this.getUserPosition();
}    

addMarker1(latLng){

  let marker1 = new google.maps.Marker({
  map: this.map,
  animation: google.maps.Animation.DROP,
  draggable: true,
  
 
  });
  marker1.setPosition(latLng);
  this.currentmarker=marker1;
let content = "<p>This is your current position !</p>";   

  let infoWindow = new google.maps.InfoWindow({
  content: content
  });

  google.maps.event.addListener(marker1, 'click', () =>  {
  //infoWindow.open(this.map, marker);
  console.log('search');
  console.log(this.currentmarker.getPosition().lat());
 console.log( this.currentmarker.getPosition().lng());

  
  this.search();
  
 
  });
  google.maps.event.addListener(marker1, 'dragend', function(event) {
    //infoWindow.open(this.map, marker);
    
    //google.maps.event.clearListeners(marker1,'click');
    this.currentlat=null;
     this.currentlng=null;
     
     this.currentlat=marker1.getPosition().lat();
     this.currentlng=marker1.getPosition().lng();
     console.log(this.currentlat);
  console.log( this.currentlng);
  let latLng = new google.maps.LatLng(this.currentlat,this.currentlng);
  this.map.setCenter(latLng);
  marker1.setPosition(latLng);
  this.currentmarker= marker1;
  
  /*google.maps.event.addListener(marker1, 'click', () => {
    //infoWindow.open(this.map, marker);
    console.log('search');
    console.log(this.currentlat);
    console.log( this.currentlng);
    this.search();
  
   
    });*/
    });
/* marker = new google.maps.Marker({
    map: this.map,
    
    position: {lat: -33.890, lng: 151.274}
     
    });*/
}
/*getUserPosition1(){
  this.options = {
  enableHighAccuracy : false
  };
  this.geolocation.getCurrentPosition(this.options).then((pos : Geoposition) => {

      this.currentPos = pos;     

      console.log(pos);
      this.addMap(pos.coords.latitude,pos.coords.longitude);
 
  },(err : PositionError)=>{
      console.log("error : " + err.message);
  ;
  })
  }*/
search (){
  this.currentmarkers.forEach(element => {
    element.setMap(null);
  });
  console.log(this.currentmarker.getPosition().lat());
  console.log( this.currentmarker.getPosition().lng());
  this.http.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+this.currentmarker.getPosition().lat()+','+this.currentmarker.getPosition().lng()+'&radius=30&types=hotel&sensor=false&key=AIzaSyDl_34S5JNPTiD_3-CVieJM0HJUmw8W720').map(res => res.json()).subscribe(data => {
      this.posts = data.results;
     // console.log(this.posts);
      this.posts.forEach(element => {
       
        var image = 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png';

          let marker = new google.maps.Marker({
          map: this.map,
          animation: google.maps.Animation.DROP,
          position: element.geometry.location,
          icon: image
          });
           this.currentmarkers.push(marker) ;        
          let infoWindow = new google.maps.InfoWindow({
          content: element.name
         }); 
         google.maps.event.addListener(marker, 'click', () => {
          infoWindow.open(this.map, marker);
          
          });
     });
   });
}

}

    //this.currentPos = pos;      
   // console.log(pos.coords.latitude);
    //this.addMap(pos.coords.latitude,pos.coords.longitude);

//}//,(err : PositionError)=>{
   // console.log("error : " + err.message);
//});
//}
/*addMap(lat,long){

  let latLng = new google.maps.LatLng(lat, long);

  let mapOptions = {
  center: latLng,
  zoom: 15,
  mapTypeId: google.maps.MapTypeId.ROADMAP
  }

  this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
  this.addMarker1();

}
ionViewDidLoad(){
 console.log( "page" );
  this.getUserPosition();
}    

addMarker1(){

  let marker = new google.maps.Marker({
  map: this.map,
  animation: google.maps.Animation.DROP,
  draggable: true,
  position: this.map.getCenter()
 
  });
  /*marker.addEventListener(GoogleMapsEvent.MARKER_DRAG_END).subscribe(
    data => {
        marker.getPosition()
        .then((LatLng) => {
            alert('GoogleMapsEvent.MARKER_DRAG_END Lat ~ '+LatLng.lat() + ' And Long ~ '+LatLng.lng())                                
        });
    });   
*/



  /*let content = "<p>This is your current position !</p>";          
  let infoWindow = new google.maps.InfoWindow({
  content: content
  });

  google.maps.event.addListener(marker, 'click', () => {
  //infoWindow.open(this.map, marker);
  this.search();
   console.log(this.addMarker1)
  });
   marker = new google.maps.Marker({
    map: this.map,
    
    position: {lat: -33.890, lng: 151.274}
     
    });
}
getUserPosition1(){
  this.options = {
  enableHighAccuracy : false
  };
  this.geolocation.getCurrentPosition(this.options).then((pos : Geoposition) => {

      this.currentPos = pos;     

      console.log(pos);
      this.addMap(pos.coords.latitude,pos.coords.longitude);

  },(err : PositionError)=>{
      console.log("error : " + err.message);
  ;
  })
}
//search (){
  //this.http.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+this.currentPos.coords.latitude+','+this.currentPos.coords.longitude+'&radius=300&types=hotel&sensor=false&key=AIzaSyDl_34S5JNPTiD_3-CVieJM0HJUmw8W720').map(res => res.json()).subscribe(data => {
     // this.posts = data.results;
     // console.log(this.posts);
      //this.posts.forEach(element => {
       
       // var image = 'https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png';
          
          //let marker = new google.maps.Marker({
          map: this.map,
          animation: google.maps.Animation.DROP,
          position: element.geometry.location,
          icon: image
          });
                    
          let infoWindow = new google.maps.InfoWindow({
          content: element.name
         }); 
         google.maps.event.addListener(marker, 'click', () => {
          infoWindow.open(this.map, marker);
          
          });
     });
   });
}

}*/


