import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { User } from 'firebase';
import { AngularFireAuth } from 'angularfire2/auth';

/**
 * Generated class for the LoginPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  user = {} as User;
  email:string ; 
  password:string;
  errormsg: string;
  constructor(public navCtrl: NavController, public navParams: NavParams , private afAuth: AngularFireAuth ) {
  }
  login() {
            
    this.errormsg="";
          this.afAuth.auth.signInWithEmailAndPassword(this.email,this.password)
         .then(result=>this.navCtrl.setRoot('LocationPage'))
         .catch(error=>this.errormsg=error.message);
          
   

    }
  
  
  

  ionViewDidLoad() {
    console.log('ionViewDidLoad LoginPage');
  }
}

