import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LocationPage } from './location';
import {HttpModule} from '@angular/http';


@NgModule({
  declarations: [
    LocationPage,
   
  ],
  imports: [
    IonicPageModule.forChild(LocationPage),
    HttpModule
  ],
})
export class LocationPageModule {}
