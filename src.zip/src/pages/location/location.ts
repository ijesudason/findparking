import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Http } from '@angular/http';
import {RegisterPage} from '../register/register';

/**
 * Generated class for the LocationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-location',
  templateUrl: 'location.html',
})
export class LocationPage {

  
  
 lng:string="151.195";
 lat:string="-33.867";
 posts:any;

 
  constructor(public navCtrl: NavController, public navParams: NavParams,public http: Http) {
  }
     nextPage()
 {
this.navCtrl.push(RegisterPage);
}
  
  
  ionViewDidLoad() {
    console.log('ionViewDidLoad LocationPage');
  }
  



  search (){
    this.http.get('https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+this.lat+','+this.lng+'&radius=300&types=parking&sensor=false&key=AIzaSyDl_34S5JNPTiD_3-CVieJM0HJUmw8W720').map(res => res.json()).subscribe(data => {
        this.posts = data.results;
        console.log(this.posts);
    });
  }
} 
