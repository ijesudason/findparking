import { Component,ViewChild ,ElementRef } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';

import { Geolocation ,GeolocationOptions ,Geoposition ,PositionError } from '@ionic-native/geolocation'; 

declare var google;


/**
 * Generated class for the RegisterPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  addMarker(): any {
    throw new Error("Method not implemented.");
  }

  
  options : GeolocationOptions;
  currentPos : Geoposition;
 
  @ViewChild('map') mapElement: ElementRef;
map: any;

  constructor( public navCtrl: NavController, public navParams: NavParams,private geolocation : Geolocation) {
  }
    
  getUserPosition(){
    this.options = {
        enableHighAccuracy : true
    };
  
  this.geolocation.getCurrentPosition(this.options).then((pos : Geoposition) => {

    this.currentPos = pos;      
    console.log(pos);

},(err : PositionError)=>{
    console.log("error : " + err.message);
});
}
addMap(lat,long){

  let latLng = new google.maps.LatLng(lat, long);

  let mapOptions = {
  center: latLng,
  zoom: 15,
  mapTypeId: google.maps.MapTypeId.ROADMAP
  }

  this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
  this.addMarker();

}
ionViewDidEnter(){

  this.getUserPosition();
}    
addMarker1(){

  let marker = new google.maps.Marker({
  map: this.map,
  animation: google.maps.Animation.DROP,
  position: this.map.getCenter()
  });

  let content = "<p>This is your current position !</p>";          
  let infoWindow = new google.maps.InfoWindow({
  content: content
  });

  google.maps.event.addListener(marker, 'click', () => {
  infoWindow.open(this.map, marker);
  });

}
getUserPosition1(){
  this.options = {
  enableHighAccuracy : false
  };
  this.geolocation.getCurrentPosition(this.options).then((pos : Geoposition) => {

      this.currentPos = pos;     

      console.log(pos);
      this.addMap(pos.coords.latitude,pos.coords.longitude);

  },(err : PositionError)=>{
      console.log("error : " + err.message);
  ;
  })
}


}


